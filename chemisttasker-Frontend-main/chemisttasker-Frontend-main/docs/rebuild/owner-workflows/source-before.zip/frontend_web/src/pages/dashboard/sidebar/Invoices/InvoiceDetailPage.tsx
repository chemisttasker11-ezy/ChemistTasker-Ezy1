export { default } from '../InvoiceDetailPage';
